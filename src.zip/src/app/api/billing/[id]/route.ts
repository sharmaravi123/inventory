import { NextRequest, NextResponse } from "next/server";
import { Types } from "mongoose";
import dbConnect from "@/lib/mongodb";

import BillModel, { BillDocument, BillItem, PaymentInfo } from "@/models/Bill";
import CustomerModel from "@/models/Customer";
import type { BillingItemInput, CreateBillPaymentInput } from "../route";

/* ============================================================================
   SAFE NUMBER
============================================================================ */
function toNum(v: any, fb = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fb;
}

/* ============================================================================
   PAYMENT VALIDATION
============================================================================ */

function validatePaymentUpdate(
  payment: CreateBillPaymentInput,
  total: number
): PaymentInfo {
  const mode = payment.mode;
  const cash = payment.cashAmount ?? 0;
  const upi = payment.upiAmount ?? 0;
  const card = payment.cardAmount ?? 0;

  if (cash < 0 || upi < 0 || card < 0)
    throw new Error("Payment cannot be negative");

  const collected = cash + upi + card;

  if (collected > total + 0.001)
    throw new Error("Collected cannot exceed total");

  return { mode, cashAmount: cash, upiAmount: upi, cardAmount: card };
}

function deriveStatus(
  collected: number,
  total: number,
  override?: BillDocument["status"]
): BillDocument["status"] {
  if (override) return override;

  if (collected === 0) return "PENDING";
  if (collected >= total) return "DELIVERED";
  return "PARTIALLY_PAID";
}

/* ============================================================================
   LINE CALCULATION (Same as POST)
============================================================================ */

function calcLine(input: BillingItemInput) {
  const totalItems =
    input.quantityBoxes * input.itemsPerBox + input.quantityLoose;

  let selling = input.sellingPrice;

  if (input.discountType === "PERCENT")
    selling -= (selling * input.discountValue) / 100;
  else if (input.discountType === "CASH")
    selling = Math.max(0, selling - input.discountValue);

  const gross = totalItems * selling;

  let beforeTax = gross;
  let taxAmount = 0;

  if (input.taxPercent > 0) {
    taxAmount = (gross * input.taxPercent) / (100 + input.taxPercent);
    beforeTax = gross - taxAmount;
  }

  const line: BillItem = {
    product: new Types.ObjectId(input.productId),
    warehouse: new Types.ObjectId(input.warehouseId),
    productName: input.productName,

    sellingPrice: selling,
    taxPercent: input.taxPercent,

    quantityBoxes: input.quantityBoxes,
    quantityLoose: input.quantityLoose,
    itemsPerBox: input.itemsPerBox,

    discountType: input.discountType,
    discountValue: input.discountValue,
    overridePriceForCustomer: input.overridePriceForCustomer,

    totalItems,
    totalBeforeTax: beforeTax,
    taxAmount,
    lineTotal: gross,
  };

  return {
    line,
    totals: { totalItems, beforeTax, taxAmount, lineTotal: gross },
  };
}

/* ============================================================================
   GET BILL
============================================================================ */

export async function GET(
  _req: NextRequest,
  ctx: { params: Promise<{ id: string }> }
) {
  try {
    await dbConnect();
    const { id } = await ctx.params;

    const bill = await BillModel.findById(id);
    if (!bill)
      return NextResponse.json({ error: "Bill not found" }, { status: 404 });

    return NextResponse.json({ bill });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/* ============================================================================
   PUT — UPDATE BILL
============================================================================ */

export async function PUT(
  req: NextRequest,
  ctx: { params: Promise<{ id: string }> }
) {
  try {
    await dbConnect();

    const { id } = await ctx.params;
    const bill = await BillModel.findById(id);

    if (!bill)
      return NextResponse.json({ error: "Bill not found" }, { status: 404 });

    const body = await req.json();

    /* ---------------------- CUSTOMER UPDATE ---------------------- */

    if (body.customer) {
      bill.customerInfo.name = body.customer.name;
      bill.customerInfo.phone = body.customer.phone;
      bill.customerInfo.address = body.customer.address;
      bill.customerInfo.shopName = body.customer.shopName;
      bill.customerInfo.gstNumber = body.customer.gstNumber;
    }

    /* ---------------------- BILL DATE UPDATE ---------------------- */

    if (body.billDate) {
      const dt = new Date(body.billDate);
      if (!isNaN(dt.getTime())) bill.billDate = dt;
    }

    /* ---------------------- COMPANY GST --------------------------- */

    if (typeof body.companyGstNumber === "string") {
      bill.companyGstNumber = body.companyGstNumber;
    }

    /* ---------------------- ITEMS UPDATE -------------------------- */

    let itemsChanged = false;

    if (Array.isArray(body.items) && body.items.length > 0) {
      itemsChanged = true;

      let totalItems = 0;
      let totalBeforeTax = 0;
      let totalTax = 0;
      let grandTotal = 0;

      const newItems: BillItem[] = [];

      for (const it of body.items as BillingItemInput[]) {
        const { line, totals } = calcLine(it);

        newItems.push(line);

        totalItems += totals.totalItems;
        totalBeforeTax += totals.beforeTax;
        totalTax += totals.taxAmount;
        grandTotal += totals.lineTotal;

        // override price save
        if (it.overridePriceForCustomer) {
          await CustomerModel.updateOne(
            { _id: bill.customerInfo.customer },
            { $pull: { customPrices: { product: it.productId } } }
          );

          await CustomerModel.updateOne(
            { _id: bill.customerInfo.customer },
            {
              $push: {
                customPrices: {
                  product: it.productId,
                  price: it.sellingPrice,
                },
              },
            }
          );
        }
      }

      bill.items = newItems;
      bill.totalItems = totalItems;
      bill.totalBeforeTax = totalBeforeTax;
      bill.totalTax = totalTax;
      bill.grandTotal = grandTotal;
    }

    const total = bill.grandTotal;

    /* ---------------------- PAYMENT UPDATE ------------------------ */

    if (body.payment) {
      const pay = validatePaymentUpdate(body.payment, total);

      bill.payment = pay;

      const collected =
        (pay.cashAmount ?? 0) + (pay.upiAmount ?? 0) + (pay.cardAmount ?? 0);

      bill.amountCollected = collected;
      bill.balanceAmount = total - collected;
      bill.status = deriveStatus(collected, total, body.status);
    } else if (itemsChanged) {
      const pay = validatePaymentUpdate(bill.payment, total);

      bill.payment = pay;

      const collected =
        (pay.cashAmount ?? 0) + (pay.upiAmount ?? 0) + (pay.cardAmount ?? 0);

      bill.amountCollected = collected;
      bill.balanceAmount = total - collected;
      bill.status = deriveStatus(collected, total);
    }

    /* ---------------------- DRIVER & VEHICLE ---------------------- */

    if (body.driverId) bill.driver = new Types.ObjectId(body.driverId);
    if (body.vehicleNumber) bill.vehicleNumber = body.vehicleNumber;

    await bill.save();

    return NextResponse.json({ bill });
  } catch (err: any) {
    console.error("BILL UPDATE ERROR:", err.message);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
