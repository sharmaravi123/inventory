import { NextRequest, NextResponse } from "next/server";
import mongoose, { Types } from "mongoose";
import dbConnect from "@/lib/mongodb";

import BillModel, {
  BillDocument,
  BillItem,
  PaymentInfo,
  CustomerSnapshot,
} from "@/models/Bill";

import CustomerModel from "@/models/Customer";
import Stock from "@/models/Stock";
import { getNextInvoiceNumber } from "@/models/InvoiceCounter";

/* ============================================================================
   TYPES
============================================================================ */

type CreateBillCustomerInput = {
  _id?: string;
  name: string;
  shopName?: string;
  phone: string;
  address: string;
  gstNumber?: string;
};

export type BillingItemInput = {
  stockId: string;
  productId: string;
  warehouseId: string;
  productName: string;

  sellingPrice: number;
  taxPercent: number;

  quantityBoxes: number;
  quantityLoose: number;
  itemsPerBox: number;

  discountType: "NONE" | "PERCENT" | "CASH";
  discountValue: number;

  overridePriceForCustomer: boolean;
};

export type CreateBillPaymentInput = {
  mode: "CASH" | "UPI" | "CARD" | "SPLIT";
  cashAmount?: number;
  upiAmount?: number;
  cardAmount?: number;
};

type CreateBillRequestBody = {
  customer: CreateBillCustomerInput;
  items: BillingItemInput[];
  payment: CreateBillPaymentInput;

  companyGstNumber?: string;
  billDate?: string;

  driverId?: string;
  vehicleNumber?: string;
};

type CreateBillResponseBody = {
  bill: {
    _id: string;
    invoiceNumber: string;
    billDate: string;
    grandTotal: number;
  };
};

/* ============================================================================
   PAYMENT VALIDATION
============================================================================ */

function validatePayment(payment: CreateBillPaymentInput, total: number): PaymentInfo {
  const mode = payment.mode;
  const cash = payment.cashAmount ?? 0;
  const upi = payment.upiAmount ?? 0;
  const card = payment.cardAmount ?? 0;

  if (cash < 0 || upi < 0 || card < 0)
    throw new Error("Payment amounts cannot be negative");

  const collected = cash + upi + card;

  if (collected > total + 0.001)
    throw new Error("Collected amount cannot exceed total bill amount");

  return { mode, cashAmount: cash, upiAmount: upi, cardAmount: card };
}

/* ============================================================================
   CUSTOMER UPSERT
============================================================================ */

async function upsertCustomer(input: CreateBillCustomerInput) {
  if (input._id) {
    const doc = await CustomerModel.findById(input._id);
    if (doc) {
      doc.name = input.name;
      doc.shopName = input.shopName;
      doc.phone = input.phone;
      doc.address = input.address;
      doc.gstNumber = input.gstNumber;
      await doc.save();
      return doc;
    }
  }

  const c = new CustomerModel({
    name: input.name,
    shopName: input.shopName,
    phone: input.phone,
    address: input.address,
    gstNumber: input.gstNumber,
  });

  await c.save();
  return c;
}

function customerSnapshot(
  customer: any,
  input: CreateBillCustomerInput
): CustomerSnapshot {
  return {
    customer: customer._id,
    name: input.name,
    shopName: input.shopName,
    phone: input.phone,
    address: input.address,
    gstNumber: input.gstNumber,
  };
}

/* ============================================================================
   STOCK RESERVATION
============================================================================ */

async function reserveStock(items: BillingItemInput[]) {
  const grouped: Record<string, number> = {};

  for (const it of items) {
    const loose = it.quantityLoose + it.quantityBoxes * it.itemsPerBox;
    grouped[it.stockId] = (grouped[it.stockId] ?? 0) + loose;
  }

  for (const stockId of Object.keys(grouped)) {
    const usage = grouped[stockId];

    const stock = await Stock.findById(stockId).lean();
    if (!stock) throw new Error("Stock not found");

    const existingLoose = stock.looseItems ?? 0;

    const availableLoose = stock.boxes * stock.itemsPerBox + existingLoose;

    if (usage > availableLoose)
      throw new Error("Requested quantity exceeds available stock");

    const remaining = availableLoose - usage;

    const newBoxes = Math.floor(remaining / stock.itemsPerBox);
    const newLoose = remaining % stock.itemsPerBox;

    await Stock.updateOne(
      { _id: stockId },
      {
        $set: {
          boxes: newBoxes,
          looseItems: newLoose,
          loose: newLoose,
        },
      }
    );
  }
}

/* ============================================================================
   LINE CALCULATIONS
============================================================================ */

function calculateLine(it: BillingItemInput) {
  const totalItems = it.quantityBoxes * it.itemsPerBox + it.quantityLoose;

  let price = it.sellingPrice;

  if (it.discountType === "PERCENT") {
    price = price - (price * it.discountValue) / 100;
  } else if (it.discountType === "CASH") {
    price = Math.max(0, price - it.discountValue);
  }

  const gross = totalItems * price;

  let taxAmount = 0;
  let beforeTax = gross;

  if (it.taxPercent > 0) {
    taxAmount = (gross * it.taxPercent) / (100 + it.taxPercent);
    beforeTax = gross - taxAmount;
  }

  const billItem: BillItem = {
    product: new Types.ObjectId(it.productId),
    warehouse: new Types.ObjectId(it.warehouseId),
    productName: it.productName,

    sellingPrice: price,
    taxPercent: it.taxPercent,

    quantityBoxes: it.quantityBoxes,
    quantityLoose: it.quantityLoose,
    itemsPerBox: it.itemsPerBox,

    discountType: it.discountType,
    discountValue: it.discountValue,
    overridePriceForCustomer: it.overridePriceForCustomer,

    totalItems,
    totalBeforeTax: beforeTax,
    taxAmount,
    lineTotal: gross,
  };

  return {
    billItem,
    totals: { totalItems, beforeTax, taxAmount, lineTotal: gross },
  };
}

/* ============================================================================
   POST — CREATE BILL
============================================================================ */

export async function POST(
  req: NextRequest
): Promise<NextResponse<CreateBillResponseBody | { error: string }>> {
  try {
    await dbConnect();

    const body = (await req.json()) as CreateBillRequestBody;

    if (!body.items || body.items.length === 0)
      return NextResponse.json({ error: "No items selected" }, { status: 400 });

    // Reserve stock
    await reserveStock(body.items);

    let totalItems = 0;
    let totalBeforeTax = 0;
    let totalTax = 0;
    let grandTotal = 0;

    const billItems: BillItem[] = [];

    for (const it of body.items) {
      const { billItem, totals } = calculateLine(it);

      billItems.push(billItem);
      totalItems += totals.totalItems;
      totalBeforeTax += totals.beforeTax;
      totalTax += totals.taxAmount;
      grandTotal += totals.lineTotal;
    }

    // Payment
    const paymentInfo = validatePayment(body.payment, grandTotal);
    const collected =
      (paymentInfo.cashAmount ?? 0) +
      (paymentInfo.upiAmount ?? 0) +
      (paymentInfo.cardAmount ?? 0);

    // Customer upsert
    const customer = await upsertCustomer(body.customer);

    // Save override prices
    for (const it of body.items) {
      if (it.overridePriceForCustomer) {
        await CustomerModel.updateOne(
          { _id: customer._id },
          { $pull: { customPrices: { product: it.productId } } }
        );
        await CustomerModel.updateOne(
          { _id: customer._id },
          {
            $push: {
              customPrices: {
                product: it.productId,
                price: it.sellingPrice,
              },
            },
          }
        );
      }
    }

    // Create bill
    const invoiceNumber = await getNextInvoiceNumber();
    const billDate = body.billDate ? new Date(body.billDate) : new Date();

    const balanceAmount = grandTotal - collected;

    let status: BillDocument["status"] = "PENDING";
    if (collected >= grandTotal) status = "DELIVERED";
    else if (collected > 0) status = "PARTIALLY_PAID";

    const bill = new BillModel({
      invoiceNumber,
      billDate,
      customerInfo: customerSnapshot(customer, body.customer),

      companyGstNumber: body.companyGstNumber,
      items: billItems,

      totalItems,
      totalBeforeTax,
      totalTax,
      grandTotal,

      payment: paymentInfo,

      driver: body.driverId || undefined,
      vehicleNumber: body.vehicleNumber || undefined,

      amountCollected: collected,
      balanceAmount,
      status,
    });

    await bill.save();

    return NextResponse.json(
      {
        bill: {
          _id: bill._id.toString(),
          invoiceNumber: bill.invoiceNumber,
          billDate: bill.billDate.toISOString(),
          grandTotal: bill.grandTotal,
        },
      },
      { status: 201 }
    );
  } catch (err: any) {
    console.error("BILLING POST ERROR:", err.message);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/* ============================================================================
   GET — LIST BILLS
============================================================================ */

export async function GET(req: NextRequest) {
  try {
    await dbConnect();

    const s = req.nextUrl.searchParams;
    const name = s.get("customer");
    const phone = s.get("phone");

    const filter: any = {};

    if (name) filter["customerInfo.name"] = { $regex: name, $options: "i" };
    if (phone) filter["customerInfo.phone"] = { $regex: phone, $options: "i" };

    const bills = await BillModel.find(filter)
      .sort({ createdAt: -1 })
      .limit(200);

    return NextResponse.json({ bills });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
