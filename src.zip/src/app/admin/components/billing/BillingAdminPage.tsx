"use client";

import React, { useEffect, useMemo, useState } from "react";
import {
  useListBillsQuery,
  useUpdateBillMutation,
  useLazySearchCustomersQuery,
  CreateBillPayload,
  CreateBillPaymentInput,
  Bill,
} from "@/store/billingApi";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { submitBill, clearBillingError } from "@/store/billingSlice";
import { fetchInventory } from "@/store/inventorySlice";
import { fetchProducts } from "@/store/productSlice";
import { fetchWarehouses } from "@/store/warehouseSlice";

import OrderForm from "./OrderForm";
import BillList from "./BillList";
import BillPreview from "./BillPreview";
import EditPaymentModal from "./EditPaymentModal";

/* =====================================================================================
   FIXED, CLEAN TYPES
===================================================================================== */

export type CustomerFormState = {
  _id: string; // FIXED → always string (never undefined)
  name: string;
  shopName: string;
  phone: string;
  address: string;
  gstNumber: string;
};

export type BillingProductOption = {
  id: string;
  productId: string;
  warehouseId: string;
  productName: string;
  warehouseName: string;
  sellingPrice: number;
  taxPercent: number;
  itemsPerBox: number;
  boxesAvailable: number;
  looseAvailable: number;
};

export type BillFormItemState = {
  id: string;
  productSearch: string;
  selectedProduct?: BillingProductOption;
  quantityBoxes: number;
  quantityLoose: number;

  discountType: "NONE" | "PERCENT" | "CASH";
  discountValue: number;
  overridePriceForCustomer: boolean;
};

export type Totals = {
  totalItemsCount: number;
  totalBeforeTax: number;
  totalTax: number;
  grandTotal: number;
};

const createRowId = () =>
  crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2);

/* =====================================================================================
   SAFE NUMBER
===================================================================================== */
function toNumber(v: any, fb = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fb;
}

/* =====================================================================================
   INITIAL STATES
===================================================================================== */

const initialCustomer: CustomerFormState = {
  _id: "",
  name: "",
  shopName: "",
  phone: "",
  address: "",
  gstNumber: "",
};

const initialPayment: CreateBillPaymentInput = {
  mode: "CASH",
  cashAmount: 0,
  upiAmount: 0,
  cardAmount: 0,
};

const emptyItem = (): BillFormItemState => ({
  id: createRowId(),
  productSearch: "",
  selectedProduct: undefined,
  quantityBoxes: 0,
  quantityLoose: 0,
  discountType: "NONE",
  discountValue: 0,
  overridePriceForCustomer: false,
});

/* =====================================================================================
   HELPERS
===================================================================================== */

function extractId(ref: any): string {
  if (!ref) return "";
  if (typeof ref === "string") return ref;
  if (typeof ref === "object") return String(ref._id ?? ref.id ?? "");
  return "";
}

/* =====================================================================================
   PAGE COMPONENT
===================================================================================== */

const COMPANY_GST_NUMBER = "27ABCDE1234F1Z5";

export default function BillingAdminPage() {
  const dispatch = useAppDispatch();

  const inventory = useAppSelector((s) => s.inventory.items);
  const inventoryLoading = useAppSelector((s) => s.inventory.loading);

  const rawProducts = useAppSelector((s) => s.product.products);
  const rawWarehouses = useAppSelector((s) => s.warehouse.list);

  const billingState = useAppSelector((s) => s.billing);

  const [customer, setCustomer] = useState<CustomerFormState>(initialCustomer);
  const [customerSearch, setCustomerSearch] = useState("");
  const [selectedCustomerId, setSelectedCustomerId] = useState("");

  const [items, setItems] = useState<BillFormItemState[]>([emptyItem()]);
  const [selectedCustomerCustomPrices, setSelectedCustomerCustomPrices] =
    useState<Record<string, number>>({});

  const [payment, setPayment] = useState<CreateBillPaymentInput>(initialPayment);

  const [billDate, setBillDate] = useState(() =>
    new Date().toISOString().slice(0, 10)
  );

  const [showForm, setShowForm] = useState(false);
  const [billSearch, setBillSearch] = useState("");
  const [billForEdit, setBillForEdit] = useState<Bill | undefined>();
  const [billForPreview, setBillForPreview] = useState<Bill | undefined>();
  const [billForPaymentEdit, setBillForPaymentEdit] = useState<
    Bill | undefined
  >();

  const [triggerCustomerSearch, customerSearchResult] =
    useLazySearchCustomersQuery();

  const { data: billsData, isLoading, refetch } = useListBillsQuery({
    search: billSearch,
  });

  const bills = billsData?.bills ?? [];
  const [updateBill] = useUpdateBillMutation();

  /* =====================================================================================
     FETCH DATA
  ===================================================================================== */
  useEffect(() => {
    dispatch(fetchInventory());
    dispatch(fetchProducts());
    dispatch(fetchWarehouses());
  }, []);

  /* =====================================================================================
     GET PRODUCT, WAREHOUSE
  ===================================================================================== */

  const getProduct = (id: string) =>
    rawProducts?.find((p: any) => extractId(p) === id);

  const getWarehouse = (id: string) =>
    rawWarehouses?.find((w: any) => extractId(w) === id);

  /* =====================================================================================
     INVENTORY → BILLING PRODUCT OPTIONS
  ===================================================================================== */

  const billingProducts: BillingProductOption[] = useMemo(() => {
    if (!inventory) return [];

    return inventory.map((inv: any) => {
      const pid = extractId(inv.productId ?? inv.product);
      const wid = extractId(inv.warehouseId ?? inv.warehouse);

      const prod = getProduct(pid);
      const wh = getWarehouse(wid);

      const productName = prod?.name ?? "Unknown Product";
      const warehouseName = wh?.name ?? "Unknown WH";

      let sellingPrice =
        prod?.sellingPrice ??
        (prod as any)?.sellPrice ??
        (prod as any)?.price ??
        0;

      if (selectedCustomerCustomPrices[pid])
        sellingPrice = selectedCustomerCustomPrices[pid];

      const itemsPerBox = toNumber(
        prod?.perBoxItem ?? prod?.itemsPerBox ?? inv.itemsPerBox,
        1
      );

      return {
        id: String(inv._id ?? `${pid}-${wid}`),
        productId: pid,
        warehouseId: wid,
        productName,
        warehouseName,
        sellingPrice,
        taxPercent: toNumber(prod?.taxPercent ?? inv.taxPercent ?? inv.tax, 0),
        itemsPerBox,
        boxesAvailable: toNumber(inv.boxes, 0),
        looseAvailable: toNumber(inv.looseItems ?? inv.loose ?? 0),
      };
    });
  }, [inventory, rawProducts, rawWarehouses, selectedCustomerCustomPrices]);

  /* =====================================================================================
     CUSTOMER SEARCH
  ===================================================================================== */

  useEffect(() => {
    if (customerSearch.length < 2) return;
    const id = setTimeout(
      () => triggerCustomerSearch(customerSearch),
      300
    );
    return () => clearTimeout(id);
  }, [customerSearch]);

  /* =====================================================================================
     TOTAL CALCULATION
  ===================================================================================== */

  const totals: Totals = useMemo(() => {
    let totalItemsCount = 0;
    let totalBeforeTax = 0;
    let totalTax = 0;
    let grandTotal = 0;

    items.forEach((it) => {
      const p = it.selectedProduct;
      if (!p) return;

      const itemCount = it.quantityBoxes * p.itemsPerBox + it.quantityLoose;
      totalItemsCount += itemCount;

      let price = p.sellingPrice;

      if (it.discountType === "PERCENT")
        price -= (price * it.discountValue) / 100;
      else if (it.discountType === "CASH")
        price = Math.max(0, price - it.discountValue);

      const gross = itemCount * price;

      let tax = 0;
      let before = gross;

      if (p.taxPercent > 0) {
        tax = (gross * p.taxPercent) / (100 + p.taxPercent);
        before = gross - tax;
      }

      grandTotal += gross;
      totalTax += tax;
      totalBeforeTax += before;
    });

    return { totalItemsCount, totalBeforeTax, totalTax, grandTotal };
  }, [items]);

  /* =====================================================================================
     CUSTOMER SELECT FIXED (NO ERROR)
  ===================================================================================== */

  const onCustomerSelect = (id: string) => {
    const doc = customerSearchResult.data?.customers.find((c) => c._id === id);
    if (!doc) return;

    setSelectedCustomerId(id);

    setCustomer({
      _id: doc._id,
      name: doc.name,
      shopName: doc.shopName ?? "",
      phone: doc.phone,
      address: doc.address,
      gstNumber: doc.gstNumber ?? "",
    });

    const priceMap: Record<string, number> = {};
    (doc as any).customPrices?.forEach((cp: any) => {
      priceMap[String(cp.product)] = Number(cp.price);
    });

    setSelectedCustomerCustomPrices(priceMap);
  };

  /* =====================================================================================
     CREATE BILL
  ===================================================================================== */

  const createBill = async () => {
    if (!customer._id && !customer.name) return alert("Customer required");

    const validItems = items.filter(
      (it) => it.selectedProduct && (it.quantityBoxes > 0 || it.quantityLoose > 0)
    );

    if (validItems.length === 0) return alert("Add product");

    const billItems = validItems.map((it) => {
      const p = it.selectedProduct!;
      return {
        stockId: p.id,
        productId: p.productId,
        warehouseId: p.warehouseId,
        productName: p.productName,
        sellingPrice: p.sellingPrice,
        taxPercent: p.taxPercent,
        quantityBoxes: it.quantityBoxes,
        quantityLoose: it.quantityLoose,
        itemsPerBox: p.itemsPerBox,
        discountType: it.discountType,
        discountValue: it.discountValue,
        overridePriceForCustomer: it.overridePriceForCustomer,
      };
    });

    const payload: CreateBillPayload = {
      customer: { ...customer },
      companyGstNumber: COMPANY_GST_NUMBER,
      billDate: new Date(billDate).toISOString(),
      items: billItems,
      payment,
    };

    dispatch(clearBillingError());

    try {
      await dispatch(submitBill(payload)).unwrap();

      alert("Bill created");

      setCustomer(initialCustomer);
      setItems([emptyItem()]);
      setPayment(initialPayment);
      setSelectedCustomerId("");
      setCustomerSearch("");
      setBillDate(new Date().toISOString().slice(0, 10));
      setShowForm(false);

      refetch();
    } catch {}
  };

  /* =====================================================================================
     EDIT BILL
  ===================================================================================== */

  const updateBillSubmit = async () => {
    if (!billForEdit) return;

    const validItems = items.filter(
      (it) => it.selectedProduct && (it.quantityBoxes > 0 || it.quantityLoose > 0)
    );
    if (validItems.length === 0) return alert("Add product");

    const billItems = validItems.map((it) => {
      const p = it.selectedProduct!;
      return {
        stockId: p.id,
        productId: p.productId,
        warehouseId: p.warehouseId,
        productName: p.productName,
        sellingPrice: p.sellingPrice,
        taxPercent: p.taxPercent,
        quantityBoxes: it.quantityBoxes,
        quantityLoose: it.quantityLoose,
        itemsPerBox: p.itemsPerBox,
        discountType: it.discountType,
        discountValue: it.discountValue,
        overridePriceForCustomer: it.overridePriceForCustomer,
      };
    });

    const payload: CreateBillPayload = {
      customer: {
        _id: customer._id,
        name: customer.name,
        shopName: customer.shopName,
        phone: customer.phone,
        address: customer.address,
        gstNumber: customer.gstNumber,
      },
      companyGstNumber: billForEdit.companyGstNumber,
      billDate: new Date(billDate).toISOString(),
      items: billItems,
      payment,
    };

    try {
      await updateBill({ id: billForEdit._id, payload }).unwrap();

      alert("Bill updated");
      setShowForm(false);
      setBillForEdit(undefined);
      refetch();
    } catch {
      alert("Update failed");
    }
  };

  /* =====================================================================================
     LOAD BILL FOR EDIT (FIXED BillItemForClient.product ERROR)
  ===================================================================================== */

  const handleEditOrder = (bill: Bill) => {
    setBillForEdit(bill);
    setShowForm(true);

    setCustomer({
      _id: bill.customerInfo.customer as unknown as string,
      name: bill.customerInfo.name,
      shopName: bill.customerInfo.shopName ?? "",
      phone: bill.customerInfo.phone,
      address: bill.customerInfo.address,
      gstNumber: bill.customerInfo.gstNumber ?? "",
    });

    const mapped = bill.items.map((line: any) => {
      const pid = extractId(line.product);
      const wid = extractId(line.warehouse);

      const p = billingProducts.find(
        (bp) => bp.productId === pid && bp.warehouseId === wid
      );

      return {
        id: createRowId(),
        productSearch: p?.productName ?? line.productName,
        selectedProduct: p,
        quantityBoxes: line.quantityBoxes,
        quantityLoose: line.quantityLoose,
        discountType: line.discountType ?? "NONE",
        discountValue: line.discountValue ?? 0,
        overridePriceForCustomer: false,
      } as BillFormItemState;
    });

    setItems(mapped);
    setPayment(bill.payment);
    setBillDate(new Date(bill.billDate).toISOString().slice(0, 10));
  };

  /* =====================================================================================
     RENDER
  ===================================================================================== */

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Billing Management</h1>

        <div className="flex gap-2">
          <input
            value={billSearch}
            onChange={(e) => setBillSearch(e.target.value)}
            className="border px-3 py-2 text-sm rounded-lg"
            placeholder="Search bills..."
          />

          <button
            className="px-4 py-2 bg-blue-600 text-white rounded-lg"
            onClick={() => {
              setShowForm((v) => !v);
              if (!showForm) {
                setBillForEdit(undefined);
                setCustomer(initialCustomer);
                setItems([emptyItem()]);
                setPayment(initialPayment);
                setBillDate(new Date().toISOString().slice(0, 10));
              }
            }}
          >
            {showForm ? "Close" : "New Bill"}
          </button>
        </div>
      </header>

      {showForm && (
        <OrderForm
          mode={billForEdit ? "edit" : "create"}
          companyGstNumber={COMPANY_GST_NUMBER}
          customer={customer}
          setCustomer={setCustomer}
          items={items}
          setItems={setItems}
          payment={payment}
          setPayment={setPayment}
          customerSearch={customerSearch}
          setCustomerSearch={setCustomerSearch}
          selectedCustomerId={selectedCustomerId}
          customerSearchResult={customerSearchResult.data}
          billingProducts={billingProducts}
          inventoryLoading={inventoryLoading}
          totals={totals}
          onCustomerSelect={onCustomerSelect}
          onSubmit={billForEdit ? updateBillSubmit : createBill}
          isSubmitting={billingState.status === "loading"}
          lastInvoiceNumber={billingState.lastInvoiceNumber}
          isSuccess={billingState.status === "succeeded"}
          billDate={billDate}
          setBillDate={setBillDate}
        />
      )}

      <BillList
        bills={bills}
        loading={isLoading}
        onSelectBill={setBillForPreview}
        onEditPayment={setBillForPaymentEdit}
        onEditOrder={handleEditOrder}
      />

      <BillPreview
        bill={billForPreview}
        onClose={() => setBillForPreview(undefined)}
      />

      <EditPaymentModal
        bill={billForPaymentEdit}
        onClose={() => setBillForPaymentEdit(undefined)}
        onUpdated={() => refetch()}
      />
    </div>
  );
}
