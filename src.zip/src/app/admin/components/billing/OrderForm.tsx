"use client";

import React from "react";
import { Customer } from "@/store/billingApi";
import { Totals } from "./BillingAdminPage";
import { PaymentMode, CreateBillPaymentInput } from "@/store/billingApi";
import {
  BillingProductOption,
  CustomerFormState,
  BillFormItemState,
} from "./BillingAdminPage";

/* ==================================================================================
   SAFE NUMBER
================================================================================== */
function toNum(v: any, fb = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fb;
}

/* ==================================================================================
   PROPS
================================================================================== */

export type OrderFormProps = {
  mode: "create" | "edit";

  companyGstNumber: string;

  customer: CustomerFormState;
  setCustomer: React.Dispatch<React.SetStateAction<CustomerFormState>>;

  items: BillFormItemState[];
  setItems: React.Dispatch<React.SetStateAction<BillFormItemState[]>>;

  payment: CreateBillPaymentInput;
  setPayment: React.Dispatch<React.SetStateAction<CreateBillPaymentInput>>;

  customerSearch: string;
  setCustomerSearch: React.Dispatch<React.SetStateAction<string>>;
  selectedCustomerId: string;

  customerSearchResult?: { customers: Customer[] };

  billingProducts: BillingProductOption[];
  inventoryLoading: boolean;

  totals: Totals;

  onCustomerSelect: (id: string) => void;

  billDate: string;
  setBillDate: (v: string) => void;

  onSubmit: () => Promise<void>;
  isSubmitting: boolean;

  lastInvoiceNumber?: string;
  isSuccess: boolean;
};

/* ==================================================================================
   COMPONENT
================================================================================== */

export default function OrderForm({
  mode,
  companyGstNumber,
  customer,
  setCustomer,
  items,
  setItems,
  payment,
  setPayment,
  customerSearch,
  setCustomerSearch,
  selectedCustomerId,
  customerSearchResult,
  billingProducts,
  inventoryLoading,
  totals,
  onCustomerSelect,
  billDate,
  setBillDate,
  onSubmit,
  isSubmitting,
  lastInvoiceNumber,
  isSuccess,
}: OrderFormProps) {
  /* ==================================================================================
       ITEM HANDLERS
  ================================================================================== */

  const handleProductSearch = (id: string, value: string) => {
    setItems((prev) =>
      prev.map((it) => (it.id === id ? { ...it, productSearch: value } : it))
    );
  };

  const handleSelectProduct = (id: string, optionId: string) => {
    const product = billingProducts.find((p) => p.id === optionId);
    if (!product) return;

    setItems((prev) =>
      prev.map((it) =>
        it.id === id
          ? {
              ...it,
              selectedProduct: product,
              productSearch: product.productName,
              quantityBoxes: 0,
              quantityLoose: 0,
              discountType: "NONE",
              discountValue: 0,
              overridePriceForCustomer: false,
            }
          : it
      )
    );
  };

  const handleQuantity = (
    id: string,
    field: "quantityBoxes" | "quantityLoose",
    value: number
  ) => {
    setItems((prev) =>
      prev.map((it) => {
        if (it.id !== id) return it;
        if (!it.selectedProduct) return it;

        const p = it.selectedProduct;
        const next = { ...it, [field]: value };

        const requested =
          next.quantityBoxes * p.itemsPerBox + next.quantityLoose;

        const available =
          p.boxesAvailable * p.itemsPerBox + p.looseAvailable;

        if (requested > available) return it;

        return next;
      })
    );
  };

  const handleEditSellingPrice = (id: string, v: number) => {
    setItems((prev) =>
      prev.map((it) =>
        it.id === id && it.selectedProduct
          ? {
              ...it,
              selectedProduct: {
                ...it.selectedProduct,
                sellingPrice: v,
              },
            }
          : it
      )
    );
  };

  const setDiscountType = (
    id: string,
    dt: BillFormItemState["discountType"]
  ) => {
    setItems((prev) =>
      prev.map((it) =>
        it.id === id ? { ...it, discountType: dt, discountValue: 0 } : it
      )
    );
  };

  const setDiscountValue = (id: string, value: number) => {
    setItems((prev) =>
      prev.map((it) =>
        it.id === id ? { ...it, discountValue: value } : it
      )
    );
  };

  const toggleOverride = (id: string, checked: boolean) => {
    setItems((prev) =>
      prev.map((it) =>
        it.id === id
          ? { ...it, overridePriceForCustomer: checked }
          : it
      )
    );
  };

  const addRow = () =>
    setItems((prev) => [
      ...prev,
      {
        id: Math.random().toString(36).slice(2),
        productSearch: "",
        selectedProduct: undefined,
        quantityBoxes: 0,
        quantityLoose: 0,
        discountType: "NONE",
        discountValue: 0,
        overridePriceForCustomer: false,
      },
    ]);

  const removeRow = (id: string) =>
    setItems((prev) => (prev.length <= 1 ? prev : prev.filter((it) => it.id !== id)));

  /* ==================================================================================
       PAYMENT HANDLERS
  ================================================================================== */

  const setPayMode = (m: PaymentMode) =>
    setPayment((prev) => ({ ...prev, mode: m }));

  /* ==================================================================================
       RENDER
  ================================================================================== */

  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold">
        {mode === "create" ? "Create Bill" : "Edit Bill"}
      </h2>

      {/* CUSTOMER SECTION */}
      <section className="grid md:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-xl">
        <div>
          <h3 className="font-semibold mb-2">Customer</h3>

          <input
            className="border rounded-lg px-3 py-2 w-full text-sm mb-2"
            placeholder="Search customer..."
            value={customerSearch}
            onChange={(e) => setCustomerSearch(e.target.value)}
          />

          {customerSearchResult?.customers?.length ? (
            <div className="border rounded-lg max-h-40 overflow-y-auto bg-white text-sm mb-2">
              {customerSearchResult.customers.map((c) => (
                <button
                  key={c._id}
                  className={`w-full text-left px-3 py-2 hover:bg-gray-100 ${
                    selectedCustomerId === c._id ? "bg-gray-200" : ""
                  }`}
                  onClick={() => onCustomerSelect(c._id)}
                  type="button"
                >
                  {c.name} — {c.phone}
                </button>
              ))}
            </div>
          ) : null}

          {/* Customer Form */}
          <div className="space-y-2 text-sm">
            <label className="block">
              Name
              <input
                className="border rounded-lg px-3 py-2 w-full"
                value={customer.name}
                onChange={(e) =>
                  setCustomer((prev) => ({ ...prev, name: e.target.value }))
                }
              />
            </label>

            <label className="block">
              Shop
              <input
                className="border rounded-lg px-3 py-2 w-full"
                value={customer.shopName}
                onChange={(e) =>
                  setCustomer((prev) => ({ ...prev, shopName: e.target.value }))
                }
              />
            </label>

            <label className="block">
              Phone
              <input
                className="border rounded-lg px-3 py-2 w-full"
                value={customer.phone}
                onChange={(e) =>
                  setCustomer((prev) => ({ ...prev, phone: e.target.value }))
                }
              />
            </label>

            <label className="block">
              Address
              <textarea
                className="border rounded-lg px-3 py-2 w-full"
                rows={2}
                value={customer.address}
                onChange={(e) =>
                  setCustomer((prev) => ({ ...prev, address: e.target.value }))
                }
              />
            </label>

            <label className="block">
              GST
              <input
                className="border rounded-lg px-3 py-2 w-full"
                value={customer.gstNumber}
                onChange={(e) =>
                  setCustomer((prev) => ({ ...prev, gstNumber: e.target.value }))
                }
              />
            </label>
          </div>
        </div>

        {/* BILL INFO */}
        <div className="space-y-3">
          <h3 className="font-semibold">Bill Details</h3>

          <div className="p-3 border rounded-md bg-white">
            <p className="text-xs text-gray-500">Company GST</p>
            <p className="font-semibold">{companyGstNumber}</p>
          </div>

          <label className="block text-xs font-medium">Bill Date</label>
          <input
            type="date"
            className="border rounded-lg px-3 py-2"
            value={billDate}
            onChange={(e) => setBillDate(e.target.value)}
          />
        </div>
      </section>

      {/* PRODUCT LIST */}
      <section className="p-4 bg-white rounded-xl shadow-sm space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="font-semibold">Products</h3>
          <button
            className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-sm"
            onClick={addRow}
          >
            + Add Item
          </button>
        </div>

        {inventoryLoading && (
          <p className="text-sm text-gray-500">Loading inventory...</p>
        )}

        {items.map((row, idx) => {
          const p = row.selectedProduct;

          const maxLoose = p
            ? p.itemsPerBox * p.boxesAvailable + p.looseAvailable
            : 0;

          const list =
            row.productSearch.length === 0
              ? billingProducts.slice(0, 25)
              : billingProducts.filter((bp) =>
                  bp.productName
                    .toLowerCase()
                    .includes(row.productSearch.toLowerCase())
                );

          return (
            <div key={row.id} className="border rounded-lg p-3 space-y-3">
              <div className="flex justify-between">
                <p className="font-medium">Item {idx + 1}</p>
                <button
                  className="text-xs text-red-600"
                  disabled={items.length === 1}
                  onClick={() => removeRow(row.id)}
                >
                  Remove
                </button>
              </div>

              {/* Product */}
              <div className="grid md:grid-cols-3 gap-3 text-sm">
                <div className="space-y-2 md:col-span-2">
                  <input
                    className="border rounded-lg px-3 py-2 w-full"
                    placeholder="Search product"
                    value={row.productSearch}
                    onChange={(e) =>
                      handleProductSearch(row.id, e.target.value)
                    }
                  />

                  <select
                    className="border rounded-lg px-3 py-2 w-full"
                    value={p?.id ?? ""}
                    onChange={(e) =>
                      handleSelectProduct(row.id, e.target.value)
                    }
                  >
                    <option value="">Select Product</option>
                    {list.map((bp) => (
                      <option key={bp.id} value={bp.id}>
                        {bp.productName} — ₹{bp.sellingPrice}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Qty */}
                <div className="space-y-2">
                  <label className="block text-xs">Boxes</label>
                  <input
                    type="number"
                    className="border rounded-lg px-3 py-2 w-full"
                    min={0}
                    value={row.quantityBoxes}
                    onChange={(e) =>
                      handleQuantity(
                        row.id,
                        "quantityBoxes",
                        toNum(e.target.value)
                      )
                    }
                  />

                  <label className="block text-xs">Loose</label>
                  <input
                    type="number"
                    className="border rounded-lg px-3 py-2 w-full"
                    min={0}
                    value={row.quantityLoose}
                    onChange={(e) =>
                      handleQuantity(
                        row.id,
                        "quantityLoose",
                        toNum(e.target.value)
                      )
                    }
                  />

                  {p && (
                    <p className="text-xs text-gray-500">
                      Max {maxLoose} items ({p.boxesAvailable} box +
                      {p.looseAvailable} loose)
                    </p>
                  )}
                </div>
              </div>

              {/* PRICE + DISCOUNT */}
              {p && (
                <div className="grid md:grid-cols-3 gap-3 text-sm">
                  <div>
                    <label className="block text-xs">Selling Price</label>
                    <input
                      type="number"
                      className="border rounded-lg px-3 py-2 w-full"
                      value={p.sellingPrice}
                      min={0}
                      onChange={(e) =>
                        handleEditSellingPrice(row.id, toNum(e.target.value))
                      }
                    />
                  </div>

                  <div>
                    <label className="block text-xs">Discount Type</label>
                    <select
                      className="border rounded-lg px-3 py-2 w-full"
                      value={row.discountType}
                      onChange={(e) =>
                        setDiscountType(
                          row.id,
                          e.target.value as BillFormItemState["discountType"]
                        )
                      }
                    >
                      <option value="NONE">NONE</option>
                      <option value="PERCENT">PERCENT (%)</option>
                      <option value="CASH">CASH (₹)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs">Discount Value</label>
                    <input
                      type="number"
                      className="border rounded-lg px-3 py-2 w-full"
                      value={row.discountValue}
                      min={0}
                      disabled={row.discountType === "NONE"}
                      onChange={(e) =>
                        setDiscountValue(row.id, toNum(e.target.value))
                      }
                    />
                  </div>

                  <div className="col-span-3 flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={row.overridePriceForCustomer}
                      onChange={(e) =>
                        toggleOverride(row.id, e.target.checked)
                      }
                    />
                    <span className="text-xs">
                      Save this price for this customer
                    </span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </section>

      {/* PAYMENT */}
      <section className="p-4 bg-gray-50 rounded-xl space-y-3">
        <h3 className="font-semibold">Payment</h3>

        <div className="flex gap-2">
          {(["CASH", "UPI", "CARD", "SPLIT"] as PaymentMode[]).map((m) => (
            <button
              key={m}
              onClick={() => setPayMode(m)}
              type="button"
              className={`px-3 py-1.5 rounded-full border ${
                payment.mode === m
                  ? "bg-blue-100 border-blue-600 text-blue-600"
                  : "border-gray-300"
              }`}
            >
              {m}
            </button>
          ))}
        </div>

        <div className="text-xs text-gray-500">
          Grand Total: ₹{totals.grandTotal.toFixed(2)}
        </div>

        {payment.mode !== "UPI" && (
          <label className="block text-sm">
            Cash
            <input
              type="number"
              className="border rounded-lg px-3 py-2 w-full"
              value={payment.cashAmount}
              min={0}
              onChange={(e) =>
                setPayment((prev) => ({
                  ...prev,
                  cashAmount: toNum(e.target.value),
                }))
              }
            />
          </label>
        )}

        {payment.mode !== "CASH" && (
          <>
            <label className="block text-sm">
              UPI
              <input
                type="number"
                className="border rounded-lg px-3 py-2 w-full"
                value={payment.upiAmount}
                min={0}
                onChange={(e) =>
                  setPayment((prev) => ({
                    ...prev,
                    upiAmount: toNum(e.target.value),
                  }))
                }
              />
            </label>

            <label className="block text-sm">
              Card
              <input
                type="number"
                className="border rounded-lg px-3 py-2 w-full"
                value={payment.cardAmount}
                min={0}
                onChange={(e) =>
                  setPayment((prev) => ({
                    ...prev,
                    cardAmount: toNum(e.target.value),
                  }))
                }
              />
            </label>
          </>
        )}
      </section>

      {/* SUMMARY */}
      <section className="p-4 bg-white rounded-xl shadow-sm text-sm space-y-1">
        <h3 className="font-semibold">Summary</h3>

        <div className="flex justify-between">
          <span>Total Items</span>
          <span>{totals.totalItemsCount}</span>
        </div>

        <div className="flex justify-between">
          <span>Subtotal</span>
          <span>₹{totals.totalBeforeTax.toFixed(2)}</span>
        </div>

        <div className="flex justify-between">
          <span>Tax</span>
          <span>₹{totals.totalTax.toFixed(2)}</span>
        </div>

        <div className="flex justify-between text-lg font-semibold border-t pt-2">
          <span>Grand Total</span>
          <span>₹{totals.grandTotal.toFixed(2)}</span>
        </div>

        <button
          className="mt-4 w-full bg-blue-600 text-white rounded-lg px-4 py-2"
          disabled={isSubmitting}
          onClick={onSubmit}
        >
          {isSubmitting
            ? mode === "create"
              ? "Creating..."
              : "Updating..."
            : mode === "create"
            ? "Create Bill"
            : "Update Bill"}
        </button>

        {mode === "create" && isSuccess && lastInvoiceNumber && (
          <p className="text-xs text-green-600 mt-1">
            Bill created: {lastInvoiceNumber}
          </p>
        )}
      </section>
    </div>
  );
}
